package stepDefinitions;

import commons.core.WebDriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pages.GlobalPage;
import pages.MailsacPage;
import pages.SearchPage;

public class EmailVerificaitonStepDef {



  MailsacPage mailsacPage;

  public EmailVerificaitonStepDef() throws Exception {
    WebDriver webDriver = new WebDriverFactory().getWebDriver();
    mailsacPage = new MailsacPage(webDriver);
  }

  @Given("the user has open the email with {string}")
  public void theUserHasOpenTheEmailWith(String Email) throws Exception {
    mailsacPage.navigateToEmailAddress(Email);
  }


  @When("the user verifies the subject in email for confirmation with booking ID")
  public void theUserVerifiesTheSubjectInEmailForConfirmationWithBookingID() {
    String [] input = new String[]{"207052","TEST","confirmed"};
    mailsacPage.verifyEmailSubject(2,input);
    String [] input1 = new String[]{"207052X","TEST","cancelled"};
    mailsacPage.verifyEmailSubject(1,input1);

  }


  @Then("the user gets in to email to see body content is same as booked")
  public void theUserGetsInToEmailToSeeBodyContentIsSameAsBooked() throws Exception {
    mailsacPage.openEmail(2,true);
    mailsacPage.verifyConfirmationNumber_bookingConfirmation("207052");
    Boolean confirm = mailsacPage.verifyConfirmationNumber_bookingConfirmation("207052");
    System.out.println("confirmation number is verfied " + confirm);
  }

  @And("the user has option to cancel the booking from the mail body")
  public void theUserHasOptionToCancelTheBookingFromTheMailBody() {
    System.out.println("check for cancellation button : " + mailsacPage.clickCancelBookingButton_bookingConfirmation());
  }
}
