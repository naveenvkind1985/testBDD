package stepDefinitions;


import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import commons.core.WebDriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import pages.GlobalPage;
import pages.LandingPage;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class LandingPageStepDef {
  LandingPage landingPage;
  GlobalPage globalPage;

  public LandingPageStepDef() {
    WebDriver webDriver = new WebDriverFactory().getWebDriver();
    landingPage = new LandingPage(webDriver);
    globalPage = new GlobalPage(webDriver);
  }

  @Given("i have launched the website")
  public void iHaveLaunchedTheWebsite() {
    assertTrue(landingPage.homePgLanding(), "Landing Home Page not loaded");
  }

  @And("user should be able to see the cookies pop up")
  public void userShouldBeAbleToSeeTheCookiesPopUp() {
    if (landingPage.popupClick() == true) {
      ExtentCucumberAdapter.addTestStepLog("Cookies is Displayed in the home pages");
    } else {
      ExtentCucumberAdapter.addTestStepLog("cookies is Not Displayed in the home pages");
    }
  }


  @Then("user should be able to see EcoHotels.com Logo")
  public void userShouldBeAbleToSeeEcoHotelsComLogo() {

    if (landingPage.homePgLanding() == true) {
      assertTrue(landingPage.homePgLanding(), "user is not able to see EcoHotels Logo");
      ExtentCucumberAdapter.addTestStepLog("Eco Hotels Logo is Displayed in the home pages");
    } else {
      ExtentCucumberAdapter.addTestStepLog("Eco Hotels Logo is Not Displayed in the home pages");
    }
  }

  @Then("user verifies landing page text {string}")
  public void userVerifiesLandingPageText(String Text) {
    if(landingPage.homePgLandingtext() != null) {
    assertTrue(landingPage.homePgLandingtext().contains(Text), "Expected Text is :- " + Text + " And Actual text is :- " + landingPage.homePgLandingtext());
      ExtentCucumberAdapter.addTestStepLog("Home Page text is displayed as " + landingPage.homePgLandingtext() );
    }else {
     // assertTrue(landingPage.homePgLandingtext().contains(Text), "Expected Text is :- " + Text + " And Actual text is :- " + landingPage.homePgLandingtext());
      ExtentCucumberAdapter.addTestStepLog("Home Page text is displayed as " + landingPage.homePgLandingtext() );
    }
  }

  @Then("user should be able to see the search form fields")
  public void userShouldBeAbleToSeeTheSearchFormFields() {
    if (landingPage.SearchFormVerification() == true) {
    assertTrue(landingPage.SearchFormVerification(), " The Search Form text field is not enabled");
      ExtentCucumberAdapter.addTestStepLog("Search form Feilds are visible and enabled for user to search for stay");
    } else {
      ExtentCucumberAdapter.addTestStepLog("Search form Feilds are visible but not enabled for user to search for stay");
    }
}

  @Then("user verifies justify content from home page with text {string}")
  public void userVerifiesJustifyContentFromHomePageWithText(String Text) {
    landingPage.clickDownArrow();
    String book= landingPage.bookwithus();
    assertEquals(Text,book,"Expected text is :- " +  Text + " and actual text is :- " +  book) ;
    ExtentCucumberAdapter.addTestStepLog("Justofy Content has been verfied sucessfully");
  }

  @And("user also verifies the sliders main row and its content")
  public void userAlsoVerifiesTheSlidersMainRowAndItsContent() throws Exception {
    landingPage.sliders();
    landingPage.sliderText();
    landingPage.sliderReadMoreLink();
    System.out.println("printing size of the link :- "+  landingPage.sliderReadMoreLink());
  }


}
