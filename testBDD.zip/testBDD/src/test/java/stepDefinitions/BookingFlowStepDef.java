package stepDefinitions;

import commons.core.WebDriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.it.Ma;
import org.openqa.selenium.WebDriver;
import pages.GlobalPage;
import pages.MailsacPage;
import pages.SearchPage;


public class BookingFlowStepDef {

  GlobalPage globalPage;
  SearchPage searchpage;
  MailsacPage mailsacPage;

  public BookingFlowStepDef() {
    WebDriver webDriver = new WebDriverFactory().getWebDriver();
    searchpage = new SearchPage(webDriver);
    globalPage = new GlobalPage(webDriver);
  }

  @When("the user is searching for a hotel {string} with {string} {string} Information")
  public void theUserIsSearchingForAHotelWithInformation(String destination, String checkin, String checkout) {
    searchpage.enterDestination(destination);
    searchpage.enterCheckinCheckoutDate(checkin, checkout);
    searchpage.searchForResults();
  }

  @And("the user should land on the search results page with a list of properties including {string} searching")
  public void theUserShouldLandOnTheSearchResultsPageWithAListOfPropertiesIncludingSearching(String Hotel) {
    searchpage.searchPageResults();
    searchpage.searchHotelNameinResults(Hotel);

  }


  @And("the user clicks on the property to view the hotel {string}")
  public void theUserClicksOnThePropertyToViewTheHotel(String Hotel) {
    searchpage.viewTheHotel();
  }

  @Then("the user should be able to see the {string} page to book")
  public void theUserShouldBeAbleToSeeThePageToBook(String Hotel) {
    searchpage.verifyHotelpage(Hotel);
  }

  @When("the user scrolls down user should be able to a see map stating your stay location with {string}")
  public void theUserScrollsDownUserShouldBeAbleToASeeMapStatingYourStayLocationWith(String textAboveMap) {
    searchpage.verifyingMapAndTextinHotelPage(textAboveMap);
  }

  @And("the user clicks on the reserve button to view Add-ons Page")
  public void theUserClicksOnTheReserveButtonToViewAddOnsPage() {
    searchpage.navigatetoAddonpage();
  }

  @When("the user chooses add-ons {string}")
  public void theUserChoosesAddOns(String hotel) {
    searchpage.chooseAddOns(hotel);
  }

  @And("the price is added to your stay details with the total cost for stay updated")
  public void thePriceIsAddedToYourStayDetailsWithTheTotalCostForStayUpdated() {
    searchpage.TotalCostForBookingWithAddons();
  }

  @And("the user clicks on updating your details")
  public void theUserClicksOnUpdatingYourDetails() {
    searchpage.enterYourDetailsForBooking();
  }

  @Then("the user should be able to update his personal details {string} {string} {string} along with card details card details for payment")
  public void theUserShouldBeAbleToUpdateHisPersonalDetailsAlongWithCardDetailsCardDetailsForPayment(String Name, String surname, String Mail) {
    searchpage. udpateUserDetailsToBook(Name,surname,Mail);
  }

  @And("click on confirm the booking to see confirmation of booking {string} and {string} with {string}")
  public void clickOnConfirmTheBookingToSeeConfirmationOfBookingAnd(String hotel, String eMail,String firstName) throws Exception {
    String bookingID = searchpage.confirmBooking(hotel);
    searchpage.cancelBooking();
 /*   firstName = firstName.toUpperCase();
    String[] input = new String[]{"cancelled", bookingID, firstName};
    mailsacPage.verifyEmailSubject(1, input);
    mailsacPage.navigateToEmailAddress(eMail);*/
  }



}
