package pages;

public enum EmailType {
    BOOKING_CONFIRMATION,
    BOOKING_CANCELLATION
}
