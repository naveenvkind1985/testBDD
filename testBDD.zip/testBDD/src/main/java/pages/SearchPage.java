package pages;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import commons.utils.CommonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class SearchPage extends GlobalPage {

  CommonUtils utils = new CommonUtils();
  public static String stayCost, addon1, addon2, HotelName, addonName, baseRoomFare, addonCost, TotalAdOnCostDetails, TotalBookingCost,
    fname, Sname, confirmTotalPrice, helpDetails, confirmorderDetails, bookingConfirmationID;

  String xPathGivenDay = "//div[contains(@class,'pika-single is-bound')][not(contains(@class,'hidden'))]//td[@data-day='___'][not(contains(@class,'is-disabled'))]";

  @FindBy(id = "destination")
  private WebElement txtBxDestination;

  @FindBy(id = "show-search")
  private WebElement txtBxDestinationMobile;

  @FindBy(id = "searchbtn")
  private WebElement btnSearch;

  @FindBy(id = "checkin")
  private WebElement checkin;

  @FindBy(id = "checkout")
  private WebElement checkout;

  @FindBy(id = "greenBtn")
  private WebElement nextBtn;
  @FindBy(how = How.XPATH, using = "//*[@id=\"loop-dest\"]/div[1]/button[1]")
  private WebElement dropdownItemSearch;


  @FindBy(how = How.XPATH, using = "//*[@id=\"loop-dest\"]/div[1]/button[1]")
  private WebElement btnClickDestination;

  @FindBy(how = How.ID, using = "checkin")
  private WebElement txtBxCheckin;

  @FindBy(how = How.XPATH, using = "//div[contains(@class,'pika-single is-bound')] [not(contains(@class,'hidden'))]")
  private WebElement datePickerControl;
  @FindBy(how = How.XPATH, using = "//td[@class='is-disabled is-today']")
  private WebElement todayDate;
  @FindBy(how = How.XPATH, using = "(//div[contains(@class,'pika-single is-bound')] [not(contains(@class,'hidden'))]//div[@role='heading']//div[@class='pika-label'])[2]")
  private WebElement labelYear;
  @FindBy(how = How.XPATH, using = "(//div[contains(@class,'pika-single is-bound')] [not(contains(@class,'hidden'))]//div[@role='heading']//div[@class='pika-label'])[1]")
  private WebElement labelMonth;
  @FindBy(how = How.XPATH, using = "//div[contains(@class,'pika-single is-bound')] [not(contains(@class,'hidden'))]//div[@role='heading']//button[@class='pika-next']")
  private WebElement nextButton;

  @FindBy(how = How.XPATH, using = "//div[contains(@class,'pika-single is-bound')] [not(contains(@class,'hidden'))]//td[@class='is-startrange']")
  private WebElement dateStartRangeMark;

  @FindBy(how = How.XPATH, using = "checkout")
  private WebElement txtBxCheckout;

  @FindBy(how = How.ID, using = "searchbtn")
  private WebElement btnSearchbtn;

  @FindBy(how = How.ID, using = "destination-results-text")
  private WebElement destinationResultsText;

  @FindBy(id = "destination-results-text")
  private WebElement destinationSearchresults;

  @FindBy(id = "map_canvas")
  private WebElement mapCanvas;

  @FindBy(id = "openMapSearchPage")
  private WebElement openMapSearchPage;

  @FindBy(xpath = "//*[@id='hotellist']/div[1]/div[1]/div[2]//a/div")
  private WebElement searchedHotelName;

  @FindBy(xpath = "//*[@id='hotellist']/div[1]/div[1]/div[3]/a")
  private WebElement viewHotel;

  @FindBy(xpath = "//*[@id='hotellist']/div[1]/div[1]/div[2]/div[1]/a/div")
  private WebElement hotelHeading;

  @FindBy(xpath = "//*[@class='h2 h-divider map-divider hotel-page-divider']")
  private WebElement hereyouStay;

  @FindBy(xpath = "/html/body/main/div[4]//div[2]/div[1]//div[1]/form/div[1]//div[4]/button")
  private WebElement reserveBtnFirst;

  @FindBy(xpath = "//div[@class='xt-header-title']")
  private WebElement addonsPage;

  @FindBy(xpath = "//span[@class='value price']")
  private WebElement StayCostWithoutAddons;

  @FindBy(xpath = "//*[@class='COL-12 js-aditional-name']")
  private WebElement roomFor;

  @FindBy(xpath = "//*[@class='col-md-8 blue-pastel extra-name']")
  private List<WebElement> extra;

  @FindBy(xpath = "//*[@class='col-md-8 blue-pastel extra-name']")
  private WebElement extraq;

  @FindBy(id = "RoomInfoContainer")
  private WebElement RoomInfoContainer;

  @FindBy(xpath = "//*[@id='RoomInfoContainer']/div[2]/div[1]/div[2]//div[2]/div[5]/div[2]//div[3]")
  private WebElement babyCotAddBtn;

  @FindBy(xpath = "//*[@id='RoomInfoContainer']/div[2]/div[1]/div[2]//div[2]/div[6]/div[2]//div[3]")
  private WebElement petAddBtn;

  @FindBy(xpath = " //div[@class='col-md-4 blue-pastel price-decoration']")
  private WebElement baseRoomCost;

  @FindBy(xpath = "//div[@class='col-md-4 blue-pastel']")
  private List<WebElement> extraAddonCost;

  @FindBy(xpath = "//div[@class='col-md-4 blue-pastel']")
  private WebElement eAddonCost;

  @FindBy(xpath = "//div[@class='col-md-6 text-right total-amount']/span")
  private WebElement totalCostofBooking;

  @FindBy(xpath = "//div[@class='js-extras extra-decoration']")
  private WebElement test;

  @FindBy(xpath = "/html/body/header/div[1]/div/nav/ul/li/a/text()")
  private WebElement currency;

  @FindBy(id = "booknow")
  private WebElement bookNowbtn;

  @FindBy(xpath = "//div[@class='xt-header-title-detail d-none']")
  private WebElement confirmationPage;

  @FindBy(id = "name")
  private WebElement name;

  @FindBy(id = "sirname")
  private WebElement sirname;

  @FindBy(id = "email")
  private WebElement email;

  @FindBy(xpath = "//*[@id='countryid']/option")
  private WebElement countryid;

  @FindBy(id = "telephone")
  private WebElement telephone;

  @FindBy(id = "email-confirm")
  private WebElement emailconfirm;

  @FindBy(id = "comment")
  private WebElement comment;

  @FindBy(id = "cardNameOnCard")
  private WebElement cardNameOnCard;

  @FindBy(id = "cardNumber")
  private WebElement cardNumber;

  @FindBy(id = "cardExpirationMonth")
  private WebElement cardExpirationMonth;

  @FindBy(id = "cardExpirationYear")
  private WebElement cardExpirationYear;

  @FindBy(id = "btnBooking")
  private WebElement btnBooking;

  @FindBy(xpath = "//*[@class='container confirm-order']")
  private WebElement confirmOrder;

  @FindBy(xpath = "//*[@class='k_hotel']")
  private WebElement confirmHotelName;

  @FindBy(xpath = "//*[@class='k_price k_value total-value']")
  private WebElement confirmationPrice;

  @FindBy(xpath = "//*[@class='k_value']/input")
  private WebElement cancelBookingBtn;

  @FindBy(xpath = "//*[@class='k_help']")
  private WebElement helpContactDetails;

  @FindBy(xpath = "/html/body/main/div[2]/p")
  private WebElement cancellationTitle;

  @FindBy(xpath = "//*[@class='cancel-order justify-content-center']")
  private WebElement cancelorderConfirmation;

  @FindBy(xpath = "//*[@class='k_value']")
  private WebElement bookingId;


  //@FindBy(className = "//*[@class='accept-policy-label']")
  @FindBy(className = "accept-policy-label")
  private WebElement checkBoxPolicy;

  @FindBy(xpath = "//*[@class='btn-close']")
  private WebElement closepopUpBtn;


  /**
   * Assigning Driver instance to the page objets
   *
   * @param driver the driver
   */
  public SearchPage(WebDriver driver) {
    super(driver);
  }

  /**
   * @param destination
   */
  public void enterDestination(String destination) {
    try {
      if (isMobileView()) {
        waitForElementToBeVisible(txtBxDestinationMobile);
        click(txtBxDestinationMobile);
        System.out.println("destination hotels is " + destination);
        sendKeys(txtBxDestination, destination);
        waitForElementToBeVisible(dropdownItemSearch);
        click(dropdownItemSearch);
        click(nextBtn);
        ExtentCucumberAdapter.addTestStepLog("Entered destination as :- " + destination + " to book a stay");
      } else {
        waitForElementToBeVisible(txtBxDestination);
        System.out.println("destination hotels is " + destination);
        sendKeys(txtBxDestination, destination);
        waitForElementToBeVisible(dropdownItemSearch);
        click(dropdownItemSearch);
        String verifyDestination = txtBxDestination.getAttribute("value");
        if (verifyDestination == destination) {
          Assert.assertTrue(verifyDestination.equals(destination), "User is able to enter the text as Expected");
          utils.log().info("User is able to enter the text in Destination as :- " + destination);
        }
        ExtentCucumberAdapter.addTestStepLog("Entered destination as :- " + destination + " to book a stay");
      }
    } catch (Exception e) {
      utils.log().info("User is not able to enter the text in destination due to :- " + e.toString());
    }
  }


  public void enterCheckinCheckoutDate(String checkInDay, String checkOutDay) {
    int checkInDa = Integer.parseInt(checkInDay);
    int checkOutDa = Integer.parseInt(checkOutDay);
    try {
      if (isMobileView()) {
        String checkInDate = utils.getAnyDayFromCurrentDay(checkInDa);
        System.out.println("checkin date is " + checkInDate);
        enterMobileDateForStay(checkInDate.split("-"));
        ExtentCucumberAdapter.addTestStepLog("Entered checkin Date as :- " + checkInDate + " to book a stay");
        String checkOutDate = utils.getAnyDayFromCurrentDay(checkOutDa);
        System.out.println("checkOutDate date is " + checkOutDate);

        //find year > month > date, navigate accordingly
        enterMobileDateForStay(checkOutDate.split("-"));
        ExtentCucumberAdapter.addTestStepLog("Entered checkout Date as :- " + checkOutDate + " to book a stay");
        click(nextBtn);
      } else {

        waitForElementToBeClickable(checkin);
        click(checkin);
        //get the actual dates
        String checkInDate = utils.getAnyDayFromCurrentDay(checkInDa);
        System.out.println("checkin date is " + checkInDate);
        enterDateForStay(checkInDate.split("-"));

        String checkOutDate = utils.getAnyDayFromCurrentDay(checkOutDa);
        System.out.println("checkOutDate date is " + checkOutDate);

        //find year > month > date, navigate accordingly
        enterDateForStay(checkOutDate.split("-"));

      }
    } catch (Exception e) {
      utils.log().info("User is not able to enter the text in Checkin and Checkout date due to :- " + e.toString());
    }
  }

  /**
   * @param dateValues
   */
  private void enterDateForStay(String[] dateValues) {
try {
    String actYear = getInnerText(labelYear);
    while (!actYear.equals(dateValues[2])) {
      click(nextButton);
      actYear = getInnerText(labelYear);
    }
    String actMonth = getInnerText(labelMonth);
    while (!dateValues[1].equalsIgnoreCase(actMonth)) {
      click(nextButton);
      actMonth = getInnerText(labelMonth);
    }
    int dateVal = Integer.parseInt(dateValues[0]);
    String xPathVal = xPathGivenDay.replace("___", String.valueOf(dateVal));
    System.out.println("date selction :- " + xPathVal);
    click(By.xpath(xPathVal));
  } catch (Exception e) {
    utils.log().info("User is not able to enter the text in Checkin and Checkout date due to :- " + e.toString());
  }
  }

  /**
   * @param dateValues
   */
  private void enterMobileDateForStay(String[] dateValues) {
    try {
      String actYear = getInnerText(labelYear);
      while (!actYear.equals(dateValues[2])) {
        click(nextButton);
        actYear = getInnerText(labelYear);
      }
      String actMonth = getInnerText(labelMonth);
      while (!dateValues[1].equalsIgnoreCase(actMonth)) {
        click(nextButton);
        actMonth = getInnerText(labelMonth);
      }
      int dateVal = Integer.parseInt(dateValues[0]);
      String xPathVal = xPathGivenDay.replace("___", String.valueOf(dateVal));
      System.out.println("date selection :- " + xPathVal);
      click(By.xpath(xPathVal));



      List<WebElement> xpathValue = driver.findElements(By.xpath(xPathVal));
      System.out.println("size " + xpathValue.size()  + " text is " + xpathValue.get(1).getText());
      jsClick(xpathValue.get(1));


    } catch (Exception e) {
      utils.log().info("User is not able to enter the text in Checkin and Checkout date due to :- " + e.toString());
    }
  }

  /**
   *
   */
  public void searchForResults() {
    try {
      waitForElementToBeVisible(btnSearchbtn);
      click(btnSearchbtn);
      waitForElementToBeVisible(destinationResultsText);
      Assert.assertTrue(destinationResultsText.isDisplayed(), "user is able to search the hotels");
      ExtentCucumberAdapter.addTestStepLog("Searching for the hotel to book a stay");
    } catch (Exception e) {
      utils.log().info("User is not able to Search due to :- " + e.toString());
    }
  }


  /**
   *
   */
  public void searchPageResults() {
    try {
      waitForElementToBeVisible(destinationSearchresults);

      isElementDisplayed(destinationSearchresults);
      String searchpageText = destinationSearchresults.getText();
      ExtentCucumberAdapter.addTestStepLog("Search Page text is displayed as : - " + searchpageText);
      isElementDisplayed(mapCanvas);
      isElementDisplayed(openMapSearchPage);
      ExtentCucumberAdapter.addTestStepLog("Search Page Map is displayed with a button to enlarge as :- " + openMapSearchPage.getText());
    } catch (Exception e) {
      utils.log().info("User is not able to Search due to :- " + e.toString());
    }
  }

  /**
   * @param hotelName
   */
  public void searchHotelNameinResults(String hotelName) {
    try {
      isElementDisplayed(searchedHotelName);
      String hotel = searchedHotelName.getText();
      Assert.assertEquals(hotelName.trim(), hotel.trim(), "user is able to find the hotel name as entered");
      ExtentCucumberAdapter.addTestStepLog("Searched hotel name for stay is :- " + hotelName + " displayed actual hotel name is  " + hotel);

    } catch (Exception e) {
      utils.log().info("User is not able to Search hotel name due to :- " + e.toString());
    }
  }


  /**
   *
   */
  public void viewTheHotel() {
    try {
      waitForElementToBeVisible(viewHotel);
      ExtentCucumberAdapter.addTestStepLog("button to view hotel name  is displayed as :- " + viewHotel.getText());
      jsClick(viewHotel);
      switchTab(1);
    } catch (Exception e) {
      utils.log().info("User is not able to view hotel button due to :- " + e.toString());
    }
  }

  /**
   * @param hotel
   */
  public void verifyHotelpage(String hotel) {
    try {
      isElementDisplayed(hotelHeading);
      HotelName = hotelHeading.getText();
      Assert.assertEquals(HotelName.trim(), hotel.trim(), "user is able to find the hotel name as entered");
      ExtentCucumberAdapter.addTestStepLog("Searched hotel name for stay is :- " + HotelName + " displayed actual hotel name is  " + hotel);
    } catch (Exception e) {
      utils.log().info("User is not able to view hotel button due to :- " + e.toString());
    }
  }

  /**
   *
   */
  public void verifyingMapAndTextinHotelPage(String textAboveMap) {
    try {
      isElementDisplayed(reserveBtnFirst);
      isElementDisplayed(StayCostWithoutAddons);
      scrollWebsiteToElement(hereyouStay);
      isElementVisible(hereyouStay);
      System.out.println("printing text above map :- " + hereyouStay.getText());
      ExtentCucumberAdapter.addTestStepLog("Text Above Map is displayed as  :- " + hereyouStay.getText() + " Expected actual Text is  " + textAboveMap);
      if (isElementDisplayed(mapCanvas)) {
        Assert.assertTrue(isElementDisplayed(mapCanvas), "user is not able to see the map in the booking page");
        ExtentCucumberAdapter.addTestStepLog("Map is displayed in the hotel booking page");
      } else {
        Assert.assertTrue(isElementDisplayed(mapCanvas), "user is not able to see the map in the booking page");
        ExtentCucumberAdapter.addTestStepLog("Map is not displayed in the hotel booking page");
      }

    } catch (Exception e) {
      utils.log().info("user is nto able to see the map in the booking page due to :- " + e.toString());
    }
  }

  /**
   *
   */
  public void navigatetoAddonpage() {
    try {
      Thread.sleep(5000);
      jsClick(reserveBtnFirst);
      waitForElementToBeVisible(addonsPage);
      System.out.println("true :- " + isElementDisplayed(addonsPage));
      if (isElementDisplayed(addonsPage)) {
        Assert.assertTrue(isElementDisplayed(addonsPage), "user is not able to see addons page ");
        ExtentCucumberAdapter.addTestStepLog(" addons page  is displayed in the hotel booking page");
      } else {
        Assert.assertTrue(isElementDisplayed(addonsPage), "user is not able to see addons page ");
        ExtentCucumberAdapter.addTestStepLog(" addons page  is not displayed in the hotel booking page");
      }
      stayCost = StayCostWithoutAddons.getText();
      System.out.println("stay cost for room is :- " + stayCost.trim());
      System.out.println("roomFor for room is :- " + roomFor.getText().trim());


    } catch (Exception e) {
      utils.log().info("User is not able to land on addon page  due to :- " + e.toString());
    }
  }


  /**
   *
   */
  public void chooseAddOns(String HotelName) {
    try {
      waitForElementToBeVisible(RoomInfoContainer);
      if (isElementDisplayed(RoomInfoContainer)) {
        baseRoomFare = baseRoomCost.getText();
        baseRoomFare = baseRoomFare.replace(" ", "");
        baseRoomFare = baseRoomFare.replace("\n\n", "");
        baseRoomFare = baseRoomFare.replace("\n", " ");
        System.out.println("replace this :- " + baseRoomFare);
        jsClick(babyCotAddBtn);
        jsClick(petAddBtn);
        TotalAdOnCostDetails = test.getText();

        String splitOn = currency.getText().toUpperCase();
        String[] TotalAddonCost = TotalAdOnCostDetails.split(splitOn);
        addon1 = TotalAddonCost[0] + " " + splitOn;
        addon2 = TotalAddonCost[1] + " " + splitOn;
      }
      ExtentCucumberAdapter.addTestStepLog("Addons page is displayed in the hotel booking page with cost of :- " + addon1 + " and " + addon2);
    } catch (Exception e) {
      utils.log().info("User is not able to land on addon page  due to :- " + e.toString());
    }
  }


  /**
   *
   */
  public void TotalCostForBookingWithAddons() {
    try {
      TotalBookingCost = totalCostofBooking.getText();
      TotalBookingCost = TotalBookingCost.replace(" ", "");
      TotalBookingCost = TotalBookingCost.replace("\n\n", "");
      TotalBookingCost = TotalBookingCost.replace("\n", " ");
      stayCost = stayCost.replaceAll("\\s+", "");
      baseRoomFare = baseRoomFare.replaceAll("\\s+", "");
      System.out.println("baseRoomFare :- " + stayCost);
      System.out.println("stayCost :- " + baseRoomFare);

      Assert.assertEquals(stayCost, baseRoomFare, "user is not able to see the Cost is same as in Booking Page and Addon Page");
      ExtentCucumberAdapter.addTestStepLog(" Addon Cost for Booking is :- " + TotalAdOnCostDetails);

      System.out.println("total booking cost is :- " + TotalBookingCost);
      if (baseRoomFare != TotalBookingCost) {
        ExtentCucumberAdapter.addTestStepLog("Total cost of room is :- " + baseRoomFare + " due to add on now the total price is " + TotalBookingCost);
      }

    } catch (Exception e) {
      utils.log().info("User is not able to land on addon page  due to :- " + e.toString());
    }
  }

  /**
   *
   */
  public void enterYourDetailsForBooking() {
    try {
      isElementDisplayed(bookNowbtn);
      jsClick(bookNowbtn);
      waitForElementToBeVisible(confirmationPage);
      if (isElementVisible(confirmationPage)) {
        ExtentCucumberAdapter.addTestStepLog("user is landed on confirmation page to book the stay");
        isElementDisplayed(name);
        isElementDisplayed(sirname);
        isElementDisplayed(email);
        isElementDisplayed(emailconfirm);
        isElementDisplayed(countryid);
        isElementDisplayed(comment);
        isElementDisplayed(cardNameOnCard);
        isElementDisplayed(cardNumber);
        isElementDisplayed(cardExpirationMonth);
        isElementDisplayed(cardExpirationYear);
        ExtentCucumberAdapter.addTestStepLog("Confirmation Page displayed with all details for user to update to book stay");
      } else {
        ExtentCucumberAdapter.addTestStepLog("Confirmation Page is not displayed with all details for user to update to book stay");
      }

    } catch (Exception e) {
      utils.log().info("User is not able to land on confirmation  due to :- " + e.toString());
    }
  }

  /**
   * Update user personal information
   *
   * @param firstname
   * @param surname
   * @param mail
   */
  public void udpateUserDetailsToBook(String firstname, String surname, String mail) {
    try {
      fname = firstname;
      Sname = surname;
      sendKeys(name, fname);
      sendKeys(sirname, Sname);
      sendKeys(email, mail);
      sendKeys(emailconfirm, mail);
      sendKeys(telephone, "89774433");
      selectrandomCountry();
      sendKeys(comment, generateString());
      switchToFrame();
      sendKeys(cardNameOnCard, firstname);
      sendKeys(cardNumber, "4242424242424242");
      sendKeys(cardExpirationMonth, "12");
      sendKeys(cardExpirationYear, "2032");
      switchToDefaultContent();
      scrollWebsiteToElement(checkBoxPolicy);
      jsClick(checkBoxPolicy);
      waitForElementToBeVisible(closepopUpBtn);
      if (isElementDisplayed(closepopUpBtn)) {
        jsClick(closepopUpBtn);
      }
      ExtentCucumberAdapter.addTestStepLog("User entered His personal Details as :- first name " + fname + " , Surname as " + Sname + " and mail id as " + mail);
    } catch (Exception e) {
      utils.log().info("User is not able to update his details  due to :- " + e.toString());
    }
  }

  /**
   * Selecting Random Country while updating personal information
   */
  public void selectrandomCountry() {
    try {
      WebElement dropdown = driver.findElement(By.xpath("//*[@id='countryid']/option"));
      Actions actions = new Actions(driver);
      actions.click(dropdown);
      //Get the list of dropdown options
      List<WebElement> itemsInDropdown = driver.findElements(By.xpath("//*[@id='countryid']/option"));
      // Get the size of dropdown list
      int size = itemsInDropdown.size();
      System.out.println("Size of the list is :- " + size);
      // Generate the random number
      int randomNumber = ThreadLocalRandom.current().nextInt(0, size);
      // Clicking on random value
      itemsInDropdown.get(randomNumber).click();
    } catch (Exception e) {
      utils.log().info("User is not able to update his details  due to :- " + e.toString());
    }
  }

  /**
   * Switch to Frame
   */
  public void switchToFrame() {
    driver.switchTo().frame("frmp");
  }

  /**
   * Switch to Default Content
   */
  public void switchToDefaultContent() {
    driver.switchTo().defaultContent();
  }

  /**
   * confirm Booking
   */
  public String confirmBooking(String hotel) {
    jsClick(btnBooking);
    waitForElementToBeVisible(confirmOrder);
    if (isElementDisplayed(confirmOrder)) {
      ExtentCucumberAdapter.addTestStepLog("User booked for stay successfully");
      System.out.println("confirmation hotel name " + confirmHotelName.getText() + " and " + hotel);
      ExtentCucumberAdapter.addTestStepLog("User booked for stay in a hotel :- " + hotel + " confined stay at hotel is :- " + confirmHotelName.getText());
      confirmTotalPrice = confirmationPrice.getText();
      confirmTotalPrice = confirmTotalPrice.replace(" ", "");
      confirmTotalPrice = confirmTotalPrice.replace("\n\n", "");
      confirmTotalPrice = confirmTotalPrice.replace("\n", " ");
      System.out.println("total booking cost is :- " + TotalBookingCost + " " + confirmTotalPrice);
      waitForElementToBeVisible(bookingId);
      bookingConfirmationID = bookingId.getText();
      ExtentCucumberAdapter.addTestStepLog("Total cost of room is before booking :- " + TotalBookingCost + "  total price after booking confirmation " + confirmTotalPrice);
    }
    return bookingConfirmationID;
  }

  /**
   *
   */
  public void cancelBooking() throws Exception {

    System.out.println("Text bookingConfirmationID  " + bookingConfirmationID);
    helpDetails = helpContactDetails.getText();
    helpDetails = helpDetails.replace(" ", "");
    helpDetails = helpDetails.replace("\n\n", "");
    helpDetails = helpDetails.replace("\n", " ");
    System.out.println("Text verification  " + helpDetails);

    confirmorderDetails = confirmOrder.getText();
    confirmorderDetails = confirmorderDetails.replace(" ", "");
    confirmorderDetails = confirmorderDetails.replace("\n\n", "");
    confirmorderDetails = confirmorderDetails.replace("\n", " ");

    System.out.println("Text confirm order Details  " + confirmorderDetails);
    System.out.println("Text bookingConfirmationID  " + bookingConfirmationID);

    scrollWebsiteToElement(cancelBookingBtn);
    Assert.assertTrue(isElementDisplayed(cancelBookingBtn), "user is nto able to see the cancellation button");
    jsClick(cancelBookingBtn);
    acceptAlert();
    Thread.sleep(5000);
    System.out.println("cancellation title is :-" + cancellationTitle.getText());
    waitForElementToBeVisible(cancelorderConfirmation);
    Assert.assertEquals("Cancellation", cancellationTitle.getText(), "user is not able to see the cancellation Page");
    if (isElementDisplayed(cancelorderConfirmation)) {
      ExtentCucumberAdapter.addTestStepLog("User is able to see cancellation message is  as  :- " + cancelorderConfirmation.getText());
    }

  }


}
