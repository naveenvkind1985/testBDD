package pages;

import commons.basepage.web.WebBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.UUID;


public class GlobalPage extends WebBase {
  WebDriver driver;
  String AlphaNumericStr;

  public GlobalPage(WebDriver driver) {
    super(driver);
    this.driver = driver;
  }

  @FindBy(className = "logo-lnk")
  private WebElement imgCompanyLogo;

  @FindBy(css = "button.ot-pc-refuse-all-handler")
  private WebElement btnPrivacyRefuse;

  public boolean isGlobalPageLoaded() {
    waitForElementToBeClickable(btnPrivacyRefuse);
    click(btnPrivacyRefuse);
    waitForInvisibilityOfAllElements(btnPrivacyRefuse);
    return isElementVisible(imgCompanyLogo);
  }

  protected boolean isMobileView() {
    int sizeWidth = driver.manage().window().getSize().getWidth();
    return sizeWidth < 1280;
  }


  public void switchTab(int Tab) {
    ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
    driver.switchTo().window(tabs2.get(Tab));
  }


  /**
   *
   * @return
   */
    public static String generateString() {
      String uuid = UUID.randomUUID().toString();
      return "uuid = " + uuid;
    }


}


