package pages;


import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import commons.utils.CommonUtils;
import java.util.ArrayList;
import java.util.List;

public class LandingPage extends GlobalPage {

  CommonUtils utils = new CommonUtils();
  @FindBy(xpath = "//img[@class='logo-image']")
  private WebElement landingPg_Logo;

  @FindBy(xpath = "//p[@class='log-description']")
  private WebElement landingPg_text;

  @FindBy(xpath = "//button[contains(text(),'Accept all')]")
  private WebElement acceptAll_btn;

  @FindBy(id = "destination")
  private WebElement destination;

  @FindBy(id = "checkin")
  private WebElement checkin;

  @FindBy(id = "checkout")
  private WebElement checkout;

  @FindBy(id = "order-people-text")
  private WebElement guests;

  @FindBy(id = "show-search")
  private WebElement showSearch;

  @FindBy(xpath = "//div[@class='go-down']")
  private WebElement goDownArrow;

  @FindBy(xpath = "//html/body/main/div[2]//div[1]/img")
  private WebElement heartImage;

  @FindBy(xpath = "//h2[contains(text(),'Why book with us?')]")
  private WebElement bookWithUs;

  @FindBy(xpath = "//html/body/main//div[2]/p")
  private WebElement bookWithUsText;

  @FindBy(xpath = "//div[@class='row main-row whyus']//h3")
  private List<WebElement> sliderheaders;

  @FindBy(xpath = "//div[@class='row main-row whyus']//p")
  private List<WebElement> sliderText;

  @FindBy(xpath = "//div[@class='row main-row whyus']//a")
  private List<WebElement> sliderreadMoreLinks;

  /**
   * Assigning Driver instance to the page objets
   *
   * @param driver the driver
   */
  public LandingPage(WebDriver driver) {
    super(driver);
  }

  /**
   * Accepting the cookies pop up
   *
   * @return
   */
  public Boolean popupClick() {
    Boolean val = null;
    if (isElementVisible(acceptAll_btn)) {
      val = isElementDisplayed(acceptAll_btn);
      System.out.println("popup is visible");
      click(acceptAll_btn);
    }
    return val;
  }

  /**
   * Verification of Logo in the home page
   *
   * @return
   */
  public boolean homePgLanding() {
    if (isMobileView()) {
      waitForElementToBeVisible(landingPg_Logo);
    } else {
      waitForElementToBeVisible(landingPg_Logo);
    }
    return isElementVisible(landingPg_Logo);
  }

  /**
   * Home page text verification
   *
   * @return
   */
  public String homePgLandingtext() {
    if (isMobileView()) {
      waitForElementToBeVisible(landingPg_text);
    } else {
      waitForElementToBeVisible(landingPg_text);
    }
    String landingPgtxt = landingPg_text.getText();
    return landingPgtxt.trim();
  }

  /**
   * Search Form verification in home page
   *
   * @return
   */
  public Boolean SearchFormVerification() {
    Boolean val;
    if (isMobileView()) {
      isElementVisible(showSearch);
      val = isElementVisible_Enabled(showSearch);
    } else {
      isElementVisible_Enabled(destination);
      isElementVisible_Enabled(checkin);
      isElementVisible_Enabled(checkout);
      isElementVisible_Enabled(guests);
      val = isElementVisible_Enabled(guests);
    }
    return val;
  }


  /**
   * Clicking on Down Arrow in Home Page
   *
   * @return
   */
  public void clickDownArrow() {
    if (isElementVisible(goDownArrow)) {
      click(goDownArrow);
      isElementDisplayed(heartImage);
    }
  }

  /**
   * Book with us text and headers text verification
   * Verify and fecth Book with us text
   *
   * @return
   */
  public String bookwithus() {
    if (isElementVisible(bookWithUs)) {
      isElementDisplayed(bookWithUs);
      isElementDisplayed(bookWithUsText);
      utils.log().info("Book with us text is dispalyed as " + bookWithUsText.getText());
      ExtentCucumberAdapter.addTestStepLog("Book with us text is dispalyed as " + bookWithUsText.getText());
    }
    return bookWithUs.getText();
  }


  /**
   * Slider headers text verification
   *
   * @return
   * @throws Exception
   */
  public List<String> sliders() throws Exception {
    List<String> sliderTxt = new ArrayList<>();
    for (WebElement element : sliderheaders) {
      sliderTxt.add(element.getText());
      ExtentCucumberAdapter.addTestStepLog("Slider Header is dispalyed as " + element.getText());
    }
    return sliderTxt;
  }


  /**
   * Slider Text verification
   *
   * @return
   * @throws Exception
   */
  public List<String> sliderText() throws Exception {
    List<String> sliderTxt = new ArrayList<>();
    for (WebElement element : sliderText) {
      sliderTxt.add(element.getText());
      utils.log().info("Sliders text is dispalyed as " + element.getText());
      ExtentCucumberAdapter.addTestStepLog("Sliders text is dispalyed as " + element.getText());
    }
    System.out.println("print slider text" + sliderTxt);
    return sliderTxt;
  }

  /**
   * Slider Link for read me more
   *
   * @return
   * @throws Exception
   */
  public List<String> sliderReadMoreLink() throws Exception {
    List<String> sliderTxt = new ArrayList<>();

    Dimension size = null;
    for (WebElement element : sliderreadMoreLinks) {
      size = element.getSize();
      sliderTxt.add(element.getText());

    }
    return sliderTxt;
  }
}



