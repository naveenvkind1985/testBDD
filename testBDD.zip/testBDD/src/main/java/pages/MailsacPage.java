package pages;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.Set;

import static java.lang.Thread.sleep;

public class MailsacPage extends GlobalPage {

    @FindBy(xpath = "/html/body/div/div[3]/div[1]/div/div[1]/button[1]")
    private WebElement purgeInboxButton;

    @FindBy(xpath = "/html/body/div/div[3]/div[1]/div/div[1]/button[2]")
    private WebElement confirmPurgeInboxButton;
    public MailsacPage(WebDriver driver) throws Exception {
        super(driver);
        String mailsac_user = "seichis";
        String  mailsac_pass= "6iDEm!egMKddkDU";
        this.login(mailsac_user,mailsac_pass);
    }


    //region  Booking Confirmation Web Elements
    //------------------------------------------------------------------------------------------------------------------------

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[2]/td/table/tbody/tr/td/div[1]")
    private WebElement hotelName_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[3]/td/table/tbody/tr/td[2]/strong")
    private WebElement confirmationNumber_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[11]/td/table/tbody/tr[2]/td[2]")
    private WebElement totalPrice_bookingConfirmation;
    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[5]/span")
    private WebElement totalPriceRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[2]/span")
    private WebElement arrivalRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[3]/span")
    private WebElement departureRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[1]/span")
    private WebElement nameRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[4]/span")
    private WebElement firstLastNameRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[1]/span")
    private WebElement numberOfAdultsRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[2]/span")
    private WebElement childrenAgeRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[2]/span")
    private WebElement numberOfInfantsRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[4]/span")
    private WebElement numberOfNightsRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[7]/td/table/tbody/tr[2]/td[1]")
    private WebElement ratesPerDayNameRoom1_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[9]/td/table/tbody/tr/td/span/text()")
    private WebElement cancellationPolicy_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[1]/span")
    private WebElement personalDetailsName_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[2]/span")
    private WebElement personalDetailsSurName_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[3]/span")
    private WebElement personalDetailsTelephone_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[4]/span")
    private WebElement personalDetailsEmail_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[5]/span")
    private WebElement personalDetailsCompany_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[1]/span")
    private WebElement personalDetailsAddress_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[2]/span")
    private WebElement personalDetailsCity_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[3]/span")
    private WebElement personalDetailsZipCode_bookingConfirmation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[4]/span")
    private WebElement personalDetailsCountry_bookingConfirmation;

    @FindBy(xpath="//*[@id=\"contentTable\"]/tbody/tr[15]/td/table/tbody/tr/td/a")
    private WebElement changeBookingButton_bookingConfirmation;

    @FindBy(xpath="//*[@id='contentTable']/tbody/tr[16]/td/table/tbody/tr/td/a")
    private WebElement cancelBookingButton_bookingConfirmation;

    //endregion

    //region Booking Cancellation Web Elements
    //------------------------------------------------------------------------------------------------------------------------
    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[2]/td/table/tbody/tr/td/div[1]")
    private WebElement hotelName_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[3]/td/table/tbody/tr/td[2]/strong")
    private WebElement confirmationNumber_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[11]/td/table/tbody/tr[2]/td[2]")
    private WebElement totalPrice_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[5]/span")
    private WebElement totalPriceRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[2]/span")
    private WebElement arrivalRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[3]/span")
    private WebElement departureRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[1]/span")
    private WebElement nameRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[1]/tbody/tr/td[4]/span")
    private WebElement firstLastNameRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[1]/span")
    private WebElement numberOfAdultsRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[2]/span")
    private WebElement childrenAgeRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[2]/span")
    private WebElement numberOfInfantsRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[5]/td/table[2]/tbody/tr/td[4]/span")
    private WebElement numberOfNightsRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[7]/td/table/tbody/tr[2]/td[1]")
    private WebElement ratesPerDayNameRoom1_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[9]/td/table/tbody/tr/td/span/text()")
    private WebElement cancellationPolicy_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[1]/span")
    private WebElement personalDetailsName_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[2]/span")
    private WebElement personalDetailsSurName_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[3]/span")
    private WebElement personalDetailsTelephone_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[4]/span")
    private WebElement personalDetailsEmail_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[21]/td/table/tbody/tr/td[5]/span")
    private WebElement personalDetailsCompany_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[1]/span")
    private WebElement personalDetailsAddress_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[2]/span")
    private WebElement personalDetailsCity_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[3]/span")
    private WebElement personalDetailsZipCode_cancellation;

    @FindBy(xpath = "//*[@id=\"contentTable\"]/tbody/tr[23]/td/table/tbody/tr/td[4]/span")
    private WebElement personalDetailsCountry_cancellation;

    //------------------------------------------------------------------------------------------------------------------------
    //endregion

    //region Booking Confirmation Verification
    //------------------------------------------------------------------------------------------------------------------------
    public boolean verifyHotelName_bookingConfirmation(String hotelName) {
        waitForElementToBeVisible(this.hotelName_bookingConfirmation);
        assert (this.hotelName_bookingConfirmation.getText().equals(hotelName));
        return true;
    }

    public boolean verifyConfirmationNumber_bookingConfirmation(String confirmationNumber) {
        waitForElementToBeVisible(this.confirmationNumber_bookingConfirmation);
        assert (this.confirmationNumber_bookingConfirmation.getText().equals(confirmationNumber));
        return true;
    }

    public boolean verifyTotalPrice_bookingConfirmation(String totalPrice) {
        waitForElementToBeVisible(this.totalPrice_bookingConfirmation);
        assert (this.totalPrice_bookingConfirmation.getText().equals(totalPrice));
        return true;
    }

    public boolean verifyTotalPriceRoom1_bookingConfirmation(String totalPriceRoom1) {
        waitForElementToBeVisible(this.totalPriceRoom1_bookingConfirmation);
        assert (this.totalPriceRoom1_bookingConfirmation.getText().equals(totalPriceRoom1));
        return true;
    }

    public boolean verifyArrivalRoom1_bookingConfirmation(String arrivalRoom1) {
        waitForElementToBeVisible(this.arrivalRoom1_bookingConfirmation);
        assert (this.arrivalRoom1_bookingConfirmation.getText().equals(arrivalRoom1));
        return true;
    }

    public boolean verifyDepartureRoom1_bookingConfirmation(String departureRoom1) {
        waitForElementToBeVisible(this.departureRoom1_bookingConfirmation);
        assert (this.departureRoom1_bookingConfirmation.getText().equals(departureRoom1));
        return true;
    }

    public boolean verifyNameRoom1_bookingConfirmation(String nameRoom1) {
        waitForElementToBeVisible(this.nameRoom1_bookingConfirmation);
        assert (this.nameRoom1_bookingConfirmation.getText().equals(nameRoom1));
        return true;
    }

    public boolean verifyFirstLastNameRoom1_bookingConfirmation(String firstLastNameRoom1) {
        waitForElementToBeVisible(this.firstLastNameRoom1_bookingConfirmation);
        assert (this.firstLastNameRoom1_bookingConfirmation.getText().equals(firstLastNameRoom1));
        return true;
    }

    public boolean verifyNumberOfAdultsRoom1_bookingConfirmation(String numberOfAdultsRoom1) {
        waitForElementToBeVisible(this.numberOfAdultsRoom1_bookingConfirmation);
        assert (this.numberOfAdultsRoom1_bookingConfirmation.getText().equals(numberOfAdultsRoom1));
        return true;
    }

    public boolean verifyChildrenAgeRoom1_bookingConfirmation(String childrenAgeRoom1) {
        waitForElementToBeVisible(this.childrenAgeRoom1_bookingConfirmation);
        assert (this.childrenAgeRoom1_bookingConfirmation.getText().equals(childrenAgeRoom1));
        return true;
    }

    public boolean verifyNumberOfInfantsRoom1_bookingConfirmation(String numberOfInfantsRoom1) {
        waitForElementToBeVisible(this.numberOfInfantsRoom1_bookingConfirmation);
        assert (this.numberOfInfantsRoom1_bookingConfirmation.getText().equals(numberOfInfantsRoom1));
        return true;
    }

    public boolean verifyNumberOfNightsRoom1_bookingConfirmation(String numberOfNightsRoom1) {
        waitForElementToBeVisible(this.numberOfNightsRoom1_bookingConfirmation);
        assert (this.numberOfNightsRoom1_bookingConfirmation.getText().equals(numberOfNightsRoom1));
        return true;
    }

    public boolean verifyRatesPerDayNameRoom1_bookingConfirmation(String ratesPerDayNameRoom1) {
        waitForElementToBeVisible(this.ratesPerDayNameRoom1_bookingConfirmation);
        assert (this.ratesPerDayNameRoom1_bookingConfirmation.getText().equals(ratesPerDayNameRoom1));
        return true;
    }

    public boolean verifyCancellationPolicy_bookingConfirmation(String cancellationPolicy) {
        waitForElementToBeVisible(this.cancellationPolicy_bookingConfirmation);
        assert (this.cancellationPolicy_bookingConfirmation.getText().equals(cancellationPolicy));
        return true;
    }

    public boolean verifyPersonalDetailsName_bookingConfirmation(String personalDetailsName) {
        waitForElementToBeVisible(this.personalDetailsName_bookingConfirmation);
        assert (this.personalDetailsName_bookingConfirmation.getText().equals(personalDetailsName));
        return true;
    }

    public boolean verifyPersonalDetailsSurName_bookingConfirmation(String personalDetailsSurName) {
        waitForElementToBeVisible(this.personalDetailsSurName_bookingConfirmation);
        assert (this.personalDetailsSurName_bookingConfirmation.getText().equals(personalDetailsSurName));
        return true;
    }

    public boolean verifyPersonalDetailsTelephone_bookingConfirmation(String personalDetailsTelephone) {
        waitForElementToBeVisible(this.personalDetailsTelephone_bookingConfirmation);
        assert (this.personalDetailsTelephone_bookingConfirmation.getText().equals(personalDetailsTelephone));
        return true;
    }

    public boolean verifyPersonalDetailsEmail_bookingConfirmation(String personalDetailsEmail) {
        waitForElementToBeVisible(this.personalDetailsEmail_bookingConfirmation);
        assert (this.personalDetailsEmail_bookingConfirmation.getText().equals(personalDetailsEmail));
        return true;
    }

    public boolean verifyPersonalDetailsCompany_bookingConfirmation(String personalDetailsCompany) {
        waitForElementToBeVisible(this.personalDetailsCompany_bookingConfirmation);
        assert (this.personalDetailsCompany_bookingConfirmation.getText().equals(personalDetailsCompany));
        return true;
    }

    public boolean verifyPersonalDetailsAddress_bookingConfirmation(String personalDetailsAddress) {
        waitForElementToBeVisible(this.personalDetailsAddress_bookingConfirmation);
        assert (this.personalDetailsAddress_bookingConfirmation.getText().equals(personalDetailsAddress));
        return true;
    }

    public boolean verifyPersonalDetailsCity_bookingConfirmation(String personalDetailsCity) {
        waitForElementToBeVisible(this.personalDetailsCity_bookingConfirmation);
        assert (this.personalDetailsCity_bookingConfirmation.getText().equals(personalDetailsCity));
        return true;
    }

    public boolean verifyPersonalDetailsZipCode_bookingConfirmation(String personalDetailsZipCode) {
        waitForElementToBeVisible(this.personalDetailsZipCode_bookingConfirmation);
        assert (this.personalDetailsZipCode_bookingConfirmation.getText().equals(personalDetailsZipCode));
        return true;
    }

    public boolean verifyPersonalDetailsCountry_bookingConfirmation(String personalDetailsCountry) {
        waitForElementToBeVisible(this.personalDetailsCountry_bookingConfirmation);
        assert (this.personalDetailsCountry_bookingConfirmation.getText().equals(personalDetailsCountry));
        return true;
    }

    public boolean clickChangeBookingButton_bookingConfirmation() {
        waitForElementToBeClickable(changeBookingButton_bookingConfirmation);
        changeBookingButton_bookingConfirmation.click();
        return true;
    }

    public boolean clickCancelBookingButton_bookingConfirmation(){
        waitForElementToBeClickable(cancelBookingButton_bookingConfirmation);
        cancelBookingButton_bookingConfirmation.click();
        return true;
    }


    //------------------------------------------------------------------------------------------------------------------------
    // endregion


    //region Cancellation Verification
    //------------------------------------------------------------------------------------------------------------------------
    public boolean verifyHotelName_cancellation(String hotelName) {
        waitForElementToBeVisible(this.hotelName_cancellation);
        assert (this.hotelName_cancellation.getText().equals(hotelName));
        return true;
    }

    public boolean verifyConfirmationNumber_cancellation(String confirmationNumber) {
        waitForElementToBeVisible(this.confirmationNumber_cancellation);
        assert (this.confirmationNumber_cancellation.getText().equals(confirmationNumber));
        return true;    }

    public boolean verifyTotalPrice_cancellation(String totalPrice) {
        waitForElementToBeVisible(this.totalPrice_cancellation);
        assert (this.totalPrice_cancellation.getText().equals(totalPrice));
        return true;
    }
    public boolean verifyTotalPriceRoom1_cancellation(String totalPriceRoom1) {
        waitForElementToBeVisible(this.totalPriceRoom1_cancellation);
        assert (this.totalPriceRoom1_cancellation.getText().equals(totalPriceRoom1));
        return true;
    }

    public boolean verifyArrivalRoom1_cancellation(String arrivalRoom1) {
        waitForElementToBeVisible(this.arrivalRoom1_cancellation);
        assert (this.arrivalRoom1_cancellation.getText().equals(arrivalRoom1));
        return true;
    }

    public boolean verifyDepartureRoom1_cancellation(String departureRoom1) {
        waitForElementToBeVisible(this.departureRoom1_cancellation);
        assert (this.departureRoom1_cancellation.getText().equals(departureRoom1));
        return true;
    }

    public boolean verifyNameRoom1_cancellation(String nameRoom1) {
        waitForElementToBeVisible(this.nameRoom1_cancellation);
        assert (this.nameRoom1_cancellation.getText().equals(nameRoom1));
        return true;
    }

    public boolean verifyFirstLastNameRoom1_cancellation(String firstLastNameRoom1) {
        waitForElementToBeVisible(this.firstLastNameRoom1_cancellation);
        assert (this.firstLastNameRoom1_cancellation.getText().equals(firstLastNameRoom1));
        return true;
    }

    public boolean verifyNumberOfAdultsRoom1_cancellation(String numberOfAdultsRoom1) {
        waitForElementToBeVisible(this.numberOfAdultsRoom1_cancellation);
        assert (this.numberOfAdultsRoom1_cancellation.getText().equals(numberOfAdultsRoom1));
        return true;
    }

    public boolean verifyChildrenAgeRoom1_cancellation(String childrenAgeRoom1) {
        waitForElementToBeVisible(this.childrenAgeRoom1_cancellation);
        assert (this.childrenAgeRoom1_cancellation.getText().equals(childrenAgeRoom1));
        return true;
    }

    public boolean verifyNumberOfInfantsRoom1_cancellation(String numberOfInfantsRoom1) {
        waitForElementToBeVisible(this.numberOfInfantsRoom1_cancellation);
        assert (this.numberOfInfantsRoom1_cancellation.getText().equals(numberOfInfantsRoom1));
        return true;
    }

    public boolean verifyNumberOfNightsRoom1_cancellation(String numberOfNightsRoom1) {
        waitForElementToBeVisible(this.numberOfNightsRoom1_cancellation);
        assert (this.numberOfNightsRoom1_cancellation.getText().equals(numberOfNightsRoom1));
        return true;
    }

    public boolean verifyRatesPerDayNameRoom1_cancellation(String ratesPerDayNameRoom1) {
        waitForElementToBeVisible(this.ratesPerDayNameRoom1_cancellation);
        assert (this.ratesPerDayNameRoom1_cancellation.getText().equals(ratesPerDayNameRoom1));
        return true;
    }

    public boolean verifyCancellationPolicy_cancellation(String cancellationPolicy) {
        waitForElementToBeVisible(this.cancellationPolicy_cancellation);
        assert (this.cancellationPolicy_cancellation.getText().equals(cancellationPolicy));
        return true;
    }

    public boolean verifyPersonalDetailsName_cancellation(String personalDetailsName) {
        waitForElementToBeVisible(this.personalDetailsName_cancellation);
        assert (this.personalDetailsName_cancellation.getText().equals(personalDetailsName));
        return true;
    }

    public boolean verifyPersonalDetailsSurName_cancellation(String personalDetailsSurName) {
        waitForElementToBeVisible(this.personalDetailsSurName_cancellation);
        assert (this.personalDetailsSurName_cancellation.getText().equals(personalDetailsSurName));
        return true;
    }

    public boolean verifyPersonalDetailsTelephone_cancellation(String personalDetailsTelephone) {
        waitForElementToBeVisible(this.personalDetailsTelephone_cancellation);
        assert (this.personalDetailsTelephone_cancellation.getText().equals(personalDetailsTelephone));
        return true;
    }

    public boolean verifyPersonalDetailsEmail_cancellation(String personalDetailsEmail) {
        waitForElementToBeVisible(this.personalDetailsEmail_cancellation);
        assert (this.personalDetailsEmail_cancellation.getText().equals(personalDetailsEmail));
        return true;
    }

    public boolean verifyPersonalDetailsCompany_cancellation(String personalDetailsCompany) {
        waitForElementToBeVisible(this.personalDetailsCompany_cancellation);
        assert (this.personalDetailsCompany_cancellation.getText().equals(personalDetailsCompany));
        return true;
    }

    public boolean verifyPersonalDetailsAddress_cancellation(String personalDetailsAddress) {
        waitForElementToBeVisible(this.personalDetailsAddress_cancellation);
        assert (this.personalDetailsAddress_cancellation.getText().equals(personalDetailsAddress));
        return true;
    }

    public boolean verifyPersonalDetailsCity_cancellation(String personalDetailsCity) {
        waitForElementToBeVisible(this.personalDetailsCity_cancellation);
        assert (this.personalDetailsCity_cancellation.getText().equals(personalDetailsCity));
        return true;
    }

    public boolean verifyPersonalDetailsZipCode_cancellation(String personalDetailsZipCode) {
        waitForElementToBeVisible(this.personalDetailsZipCode_cancellation);
        assert (this.personalDetailsZipCode_cancellation.getText().equals(personalDetailsZipCode));
        return true;
    }

    public boolean verifyPersonalDetailsCountry_cancellation(String personalDetailsCountry) {
        waitForElementToBeVisible(this.personalDetailsCountry_cancellation);
        assert (this.personalDetailsCountry_cancellation.getText().equals(personalDetailsCountry));
        return true;
    }
    //endregion


    //region Verify Email Subject

    public boolean verifyEmailSubject(int emailIndex,String[] words){
      StringBuilder stringBui = new StringBuilder();
        emailIndex++;
        String subject_xpath="/html/body/div/div[3]/div[1]/div/div[2]/div/table/tbody/tr["+emailIndex+"]/td[4]";
        WebElement subject=driver.findElement(By.xpath(subject_xpath));
        for (String word:words) {
            assert (subject.getText().contains(word));
          stringBui.append(word).append(" - ");
        }
      String finalString = stringBui.toString();
      ExtentCucumberAdapter.addTestStepLog("Email has been sent with Subject :- " + finalString);
        return true;
    }

    //endregion

    //region Public Helpers
    public boolean navigateToEmailAddress(String emailAddress) throws Exception {
        String url = "https://mailsac.com/inbox/" + emailAddress;
        driver.get(url);
        sleep(2500);
        return true;
    }

    public boolean openEmail(int emailIndex, boolean changeTab) throws Exception {
        changeTab(0);
        int unblock_LinkBtn_index= emailIndex+1;
        String email_xpath=get_email_xpath(emailIndex);
        if (waitForEmailMessageToAppear(email_xpath)){
            WebElement email = driver.findElement(By.xpath(email_xpath));
            email.click();
            Thread.sleep(2000);
            String unblock_links_images_button_xpath = "/html/body/div/div[3]/div[1]/div/div[2]/div/table/tbody/tr[" + unblock_LinkBtn_index + "]/td[2]/div[1]/a[1]";
          System.out.println("expected xpath is :-  /html/body/div/div[3]/div[1]/div/div[2]/div/table/tbody/tr[2]/td[2]/div[1]/a[1]");
          System.out.println("actual xpath is :- " + unblock_links_images_button_xpath);
            WebElement unblock_links_images_button = email.findElement(By.xpath(unblock_links_images_button_xpath));
            waitForElementToBeClickable(unblock_links_images_button);
            jsClick(unblock_links_images_button);

            if (changeTab){
                changeTab(1);
            }
            return true;
        }else{
            return false;
        }
    }
    public boolean changeTab(int index) {
        Set<String> handlesSet = driver.getWindowHandles();
        String[] handles = handlesSet.toArray(new String[handlesSet.size()]);
        driver.switchTo().window(handles[index]);
        return true;
    }
    public boolean DeleteAllEmails(){
        changeTab(0);
        waitForElementToBeClickable(this.purgeInboxButton);
        this.purgeInboxButton.click();
        waitForElementToBeClickable(this.confirmPurgeInboxButton);
        this.confirmPurgeInboxButton.click();
        return true;
    }

    //endregion

    //region Private Helpers

    private boolean waitForEmailMessageToAppear(String xpath) throws InterruptedException {
        changeTab(0);
        boolean waitingForEmail = true;

        int attempts = 0;
        while (waitingForEmail) {
            if (attempts >= 5) {
                return false;
            }
            try {
                WebElement email = driver.findElement(By.xpath(xpath));
                waitForElementToBeVisible(email);
                waitingForEmail = false;

            } catch (NoSuchElementException exception) {
                sleep(10000);
            }finally {
                attempts++;
            }

        }

        return true;
    }

    private boolean login(String username, String password) throws InterruptedException {
        String url_login = "https://mailsac.com/login";

        driver.get(url_login);

        String username_input_name = "username";
        WebElement username_input = driver.findElement(By.name(username_input_name));
        waitForElementToBeClickable(username_input);
        username_input.sendKeys(username);

        String password_input_name = "password";
        WebElement password_input = driver.findElement(By.name(password_input_name));
        password_input.sendKeys(password);

        String sign_in_button_xpath = "/html/body/div/div[3]/div[1]/div/div/div/form/button";
        WebElement sign_in_button = driver.findElement(By.xpath(sign_in_button_xpath));
        sign_in_button.click();
        sleep(2500);
        return true;
    }

    private String get_email_xpath(int emailIndex){
        emailIndex++; // The first index is taken by a banner that shows when no emails
        return "/html/body/div/div[3]/div[1]/div/div[2]/div/table/tbody/tr[" + emailIndex + "]";
    }


    private boolean clickCancellationEmailButton() {
        return true;
    }


    //endregion

}

